<?php  
    session_start();
    if(!isset($_SESSION['user'])){
        header('Location: index.php');
    }
    $data = $_SESSION['data'];
    $sid = $data['result']['sid'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Отчет по iFobs</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Alegreya|IBM+Plex+Serif|Lora|Merriweather|Open+Sans|Philosopher|Play|Roboto+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/media.css">
    <script src="js/vue.js"></script>
    <script src="js/axios.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/Chart.min.js"></script>
    <script src="js/vue-chartjs.min.js"></script>
</head>
<body>
    <header id="app2">
        <img class="logo" src="images/logo.png" alt="logo">
        <img class="menu-logo" src="images/menu.png" alt="menu">
        <span class="login" sid="<?php echo($data['result']['sid']);?>"> <?php echo($data['result']['login']); ?></span>
        <a class="nav-link" id="exit" href="core/logout.php">Выйти</a> 
    </header>
    <div class="main">
        <div class="menu">
            <nav class="branch-data">
                <span  class="nav-box">
                    <a class="nav-select" href="data.php">
                        <span>
                            <img class="nav-icons" src="images/icons/home.png" alt="home-icon">
                            <p>Главная</p>
                        </span>
                    </a>
                </span>
                <span class="nav-box">
                    <a class="nav-select" href="branch.php">
                        <span>
                            <img class="nav-icons" src="images/icons/diag.png" alt="home-icon">
                            <p>Отчет по филиалам</p>
                        </span>
                    </a>
                </span>
                <span :class="['nav-box', {active : isActive}]">
                    <a :class="['nav-select', {'nav-select-brd': isActive}]" href="ifobs.php">
                        <span>
                        <img class="nav-icons" src="images/icons/diag2.png" alt="home-icon">
                        <p>Отчет по iFobs</p>
                        </span>
                    </a>
                </span>

            </nav>
        </div>
        <div class="info">
            <div class="set-date">
                <span class="set-data-child-1">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline1" @click="click(1)" value="1" v-model="picked">
                        <label class="custom-control-label" for="defaultInline1">День</label>
                    </div>

                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline2" @click="click(2)" value="2" v-model="picked">
                        <label class="custom-control-label" for="defaultInline2">Неделя</label>
                    </div>

                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline3" @click="click(3)" value="3" v-model="picked">
                        <label class="custom-control-label" for="defaultInline3">Месяц</label>
                    </div>

                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline4" @click="click(4)" value="4" v-model="picked">
                        <label class="custom-control-label" for="defaultInline4">Весь период</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input  type="radio" class="custom-control-input" id="defaultInline5" @click="defaultDate"  value="5" v-model="picked">
                        <label class="custom-control-label" for="defaultInline5">Произвольный период</label>
                </div>
                </span>
                <span v-if="isShow" class="set-data-child-2">
                    <input class="form-control set-date-input" type="date" v-model="date_begin" > 
                    <input class="form-control set-date-input" type="date" v-model="date_end"> 
                </span>
                <button v-if="isShow" @click="click(5)" class="btn date-btn" :disabled="dateBtn">OK</button>
            </div>
            <!--
            <span v-if="isDateShow">С {{date_begin}} до {{date_end}}</span>
            <span v-else-if="!isShow">Выбрано: {{ picked }}</span>
            <span v-else></span>
            -->
            <transition name="fade">
                <div v-if="isContent" class="ifobs-content">
                    <div v-if="isError" class="ifobs-content-box">
                        <div class="credit-debit">
                            <section class="ifobs-content-child incomeDeposits">
                                <p class="deposit-child-1">ПОСТУПЛЕНИЯ ДЕПОЗИТОВ</p>
                                <info image="images/UZS.png" text="Открыто депозитов" cur="сум"
                                :count="result.opendep_cnt_uzs"
                                :amount="toSum(result.opendep_amount_uzs)"></info>
                                <info image="images/dollar.png" text="Открыто депозитов" cur="USD"
                                :count="result.opendep_cnt_usd" :amount="toSum(result.opendep_amount_usd)"></info>
                                <span class="deposit-childs border-span"></span>    
                                <info image="images/UZS.png" text="Пополнение депозитов" cur="сум"
                                :count="result.debitdep_cnt_uzs" :amount="toSum(result.debitdep_amount_uzs)"></info>
                                <info image="images/dollar.png" text="Пополнение депозитов" cur="USD"
                                :count="result.debitdep_cnt_usd" :amount="toSum(result.debitdep_amount_usd)"></info>  
                            </section>
                            <section class="ifobs-content-child incomeDeposits">
                                <p class="deposit-child-2">ОТЧИСЛЕНИЯ ДЕПОЗИТОВ</p>
                                <info image="images/UZS.png" text="Списано с депозитов" cur="сум"
                                :count="result.creditdep_cnt_uzs"
                                :amount="toSum(result.creditdep_amount_uzs)"></info>
                                <info image="images/dollar.png" text="Списано с депозитов" cur="USD"
                                :count="result.creditdep_cnt_usd" :amount="toSum(result.creditdep_amount_usd)"></info>
                                <span class="deposit-childs border-span"></span>    
                                <info image="images/UZS.png" text="Закрыто депозитов" cur="сум"
                                :count="result.closedep_cnt_uzs" :amount="toSum(result.closedep_amount_uzs)"></info>
                                <info image="images/dollar.png" text="Закрыто депозитов" cur="USD"
                                :count="result.closedep_cnt_usd" :amount="toSum(result.closedep_amount_usd)"></info>  
                            </section>
                        </div>
                        <div class="credit-debit">
                            <span class="full-amount">
                                <p class="full-amount-left">ИТОГО: </p>
                                <span class="full-amount-right">
                                <p class="deposit-childs-amount">{{toSum(result.income_amount_uzs)}} сум</p>
                                <p class="deposit-childs-amount">{{toSum(result.income_amount_usd)}} USD</p>

                                </span>
                            </span>
                            <span class="full-amount">
                                <p class="full-amount-left">ИТОГО: </p>
                                <span class="full-amount-right">
                                    <p class="deposit-childs-amount">{{toSum(result.outcome_amount_uzs)}} сум</p>
                                    <p class="deposit-childs-amount">{{toSum(result.outcome_amount_usd)}} USD</p>
                                </span>
                            </span>
                        </div>
                        <div class="diff-dep" >
                            <p class="full-amount-left">РАЗНИЦА ПО ДЕП: </p>
                            <span class="full-amount-right">
                                <p :class="['deposit-childs-amount', {green: uzsGreen, red: uzsRed}]">{{uzsPlus}}{{toSum(result.full_amount_uzs)}} сум</p>
                                <p :class="['deposit-childs-amount', {green: usdGreen, red: usdRed}]">{{usdPlus}}{{toSum(result.full_amount_usd)}} USD</p>
                            </span>
                        </div>
                        <div class="currency-icons">
                            <span class="currency-icon">
                                <img class="cur-logo" src="images/uzb_flag.png" alt="uzb">
                                <h4 class="cur-text">UZS</h4>
                            </span>
                            <span class="currency-icon">
                                <img class="cur-logo" src="images/usa_flag.png" alt="uzb">
                                <h4 class="cur-text">USD</h4>
                            </span>
                        </div>
                        <div class="charts">
                            <line-chart-1></line-chart-1>
                            <line-chart-2></line-chart-2>
                        </div>
                        <div class="credit-debit other">
                            <section class="ifobs-content-child fromAccountToCard">
                                <span class="credit-debit-header">
                                    <img class="icons" src="images/c2c.png" alt="c2c-logo">
                                    <p class="deposit-child-1 other-header">С КАРТЫ НА КАРТУ</p>
                                </span>
                                <info image="images/UZS.png" text="Переводов" cur="сум"
                                :count="result.c2c_cnt" :amount="toSum(result.c2c_amount)"></info>
                        
                                <span class="deposit-childs">
                                    <img class="money-icon" src="images/UZS.png" alt="uzs">
                                    <p class="deposit-childs-text">Комиссия: </p>
                                    <p class="deposit-childs-count"></p>
                                    <p class="deposit-childs-amount">{{toSum(result.c2c_feeamount)}} сум</p>
                                </span>
                            </section>

                            <section class="ifobs-content-child fromAccountToCard">
                                <span class="credit-debit-header">
                                    <img class="icons" src="images/a2c.png" alt="a2c-logo">
                                    <p class="deposit-child-1 other-header">СО СЧЕТА НА КАРТУ</p>
                                </span>
                                <info image="images/UZS.png" text="Переводов" cur="сум"
                                :count="result.a2c_cnt" :amount="toSum(result.a2c_amount)"></info>
                        
                                <span class="deposit-childs">
                                    <img class="money-icon" src="images/UZS.png" alt="uzs">
                                    <p class="deposit-childs-text">Комиссия: </p>
                                    <p class="deposit-childs-count"></p>
                                    <p class="deposit-childs-amount">{{toSum(result.a2c_feeamount)}} сум</p>
                                </span>
                            </section>

                            <section class="ifobs-content-child fromAccountToCard">
                                <span class="credit-debit-header">
                                    <img class="icons c2a-icon" src="images/c2a.png" alt="c2a-logo">
                                    <p class="deposit-child-1 other-header">С КАРТЫ НА СЧЕТ</p>
                                </span>
                                <info image="images/UZS.png" text="Переводов" cur="сум"
                                :count="result.c2a_cnt" :amount="toSum(result.c2a_amount)"></info>
                        
                                <span class="deposit-childs">
                                    <img class="money-icon" src="images/UZS.png" alt="uzs">
                                    <p class="deposit-childs-text">Комиссия: </p>
                                    <p class="deposit-childs-count"></p>
                                    <p class="deposit-childs-amount">{{toSum(result.c2a_feeamount)}} сум</p>
                                </span>
                            </section>

                            <section class="ifobs-content-child fromAccountToCard">
                                <span class="credit-debit-header">
                                    <img class="icons payments-icon" src="images/payments.png" alt="payments">
                                    <p class="deposit-child-1 other-header">ПЛАТЕЖИ</p>
                                </span>
                                <info image="images/UZS.png" text="Переводов" cur="сум"
                                :count="result.upbs_cnt" :amount="toSum(result.upbs_amount)"></info>
                        
                                <span class="deposit-childs">
                                    <img class="money-icon" src="images/UZS.png" alt="uzs">
                                    <p class="deposit-childs-text">Комиссия: </p>
                                    <p class="deposit-childs-count"></p>
                                    <p class="deposit-childs-amount">{{toSum(result.upbs_feeamount)}} сум</p>
                                </span>
                            </section>

                            <section class="ifobs-content-child fromAccountToCard">
                                <span class="credit-debit-header">
                                    <img class="icons credit-icon" src="images/credits.png" alt="credits">
                                    <p class="deposit-child-1 other-header">ПОГАШЕНИЯ КРЕДИТОВ</p>
                                </span>
                                <info image="images/UZS.png" text="Платежей" cur="сум"
                                :count="result.credit_cnt" :amount="toSum(result.credit_amount)"></info>

                            </section>

                            <section class="ifobs-content-child fromAccountToCard">
                                <span class="credit-debit-header">
                                    <img class="icons users-icon" src="images/open_users.png" alt="open_users">
                                    <p class="deposit-child-1 other-header">ОТКРЫТО ПОЛЬЗОВАТЕЛЕЙ</p>
                                </span>
                                <span class="deposit-childs">
                                    <p class="deposit-childs-text">Через Б2: </p>
                                    <p class="deposit-childs-count"></p>
                                    <p class="deposit-childs-amount">{{result.user_front_cnt}}</p>
                                </span>
                                <span class="deposit-childs">
                                    <p class="deposit-childs-text">Саморегистрация: </p>
                                    <p class="deposit-childs-count"></p>
                                    <p class="deposit-childs-amount">{{result.user_card_amount}}</p>
                                </span>
                            </section>

                            <section class="ifobs-content-child fromAccountToCard">
                                <span class="credit-debit-header">
                                    <img class="icons conv-icon" src="images/conv1.png" alt="conversion">
                                    <p class="deposit-child-1 other-header">КОНВЕРСИЯ</p>
                                </span>
                                <info image="images/UZS.png" text="Прямая. Сум -> USD" cur="сум"
                                :count="result.c2visa_cnt_uzs" :amount="toSum(result.c2visa_amount_uzs)"></info>
                                <info image="images/dollar.png" text="Обратная. USD -> Сум" cur="USD"
                                :count="result.visa2c_cnt_usd" :amount="toSum(result.visa2c_amount_usd)"></info>
                            
                            </section>
                            
                        </div>

                    </div>
                    <div v-else class="error">
                        <h2>{{result.message}} </h2>
                        <p>код ошибки: {{result.code}}</p>
                    </div>
                    
                </div>
            </transition>

            
        </div>


    </div>

    <script src="js/vue-script.js"></script>
    <script src="js/script.js"></script>
</body>
</html>