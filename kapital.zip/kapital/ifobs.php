<?php  
    session_start();
    if(!isset($_SESSION['user'])){
        header('Location: index.php');
    }
    $data = $_SESSION['data'];
    $sid = $data['result']['sid'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Отчет по iFobs</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Alegreya|IBM+Plex+Serif|Lora|Merriweather|Open+Sans|Philosopher|Play|Roboto+Mono&display=swap" rel="stylesheet">
    <script src="js/vue.js"></script>
    <script src="js/axios.min.js"></script>
    <script src="js/jquery.min.js"></script>
</head>
<body>
    <header id="app2">
        <img class="logo" src="images/logo.png" alt="logo">
        
        <span class="login" sid="<?php echo($data['result']['sid']);?>"> <?php echo($data['result']['login']); ?></span>
        <a class="nav-link" id="exit" href="core/logout.php">Выйти</a> 
    </header>
    <div class="main">
        <div class="menu">
            <nav class="branch-data">
                <span  class="nav-box">
                    <a class="nav-select" href="data.php">
                        <span>
                            <img class="nav-icons" src="images/icons/home.png" alt="home-icon">
                            <p>Главная</p>
                        </span>
                    </a>
                </span>
                <span class="nav-box">
                    <a class="nav-select" href="branch.php">
                        <span>
                            <img class="nav-icons" src="images/icons/diag.png" alt="home-icon">
                            <p>Отчет по филиалам</p>
                        </span>
                    </a>
                </span>
                <span :class="['nav-box', {active : isActive}]">
                    <a :class="['nav-select', {'nav-select-brd': isActive}]" href="ifobs.php">
                        <span>
                        <img class="nav-icons" src="images/icons/diag2.png" alt="home-icon">
                        <p>Отчет по iFobs</p>
                        </span>
                    </a>
                </span>

            </nav>
        </div>
        <div class="info">
            <div class="set-date">
                <span class="set-data-child-1">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline1" value="1" v-model="picked">
                        <label class="custom-control-label" for="defaultInline1">День</label>
                    </div>

                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline2" value="2" v-model="picked">
                        <label class="custom-control-label" for="defaultInline2">Неделя</label>
                    </div>

                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline3" value="3" v-model="picked">
                        <label class="custom-control-label" for="defaultInline3">Месяц</label>
                    </div>

                    <div class="custom-control custom-radio custom-control-inline">
                        <input   type="radio" class="custom-control-input" id="defaultInline4" value="4" v-model="picked">
                        <label class="custom-control-label" for="defaultInline4">Весь период</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input  type="radio" class="custom-control-input" id="defaultInline5" value="5" v-model="picked">
                        <label class="custom-control-label" for="defaultInline5">Произвольный период</label>
                </div>
                </span>
                <span v-if="isShow" class="set-data-child-2">
                    <input class="form-control set-date-input" type="date" v-model="date_begin"> 
                    <input class="form-control set-date-input" type="date" v-model="date_end"> 
                </span>
                <button @click="click" class="btn date-btn" :disabled="dateBtn">OK</button>
            </div>
            <!--
            <span v-if="isDateShow">С {{date_begin}} до {{date_end}}</span>
            <span v-else-if="!isShow">Выбрано: {{ picked }}</span>
            <span v-else></span>
            -->
            <div v-if="isContent" class="ifobs-content">
                <div v-if="isError" class="ifobs-content-box">
                    <section class="ifobs-content-child fromAccountToCard">
                        <p>{{result.a2c_amount}}</p>
                        <p>{{result.a2c_cnt}}</p>
                        <p>{{result.a2c_feeamount}}</p>
                    </section>
                    <section class="ifobs-content-child fromCardToAccount">
                        <p>{{result.c2a_amount}}</p>
                        <p>{{result.c2a_cnt}}</p>
                        <p>{{result.c2a_feeamount}}</p>
                    </section>
                    <section class="ifobs-content-child fromCardToCard">
                        <p>{{result.c2c_amount}}</p>
                        <p>{{result.c2c_cnt}}</p>
                        <p>{{result.c2c_feeamount}}</p>
                    </section>
                    <section class="ifobs-content-child conversion">
                        <p>{{result.c2visa_amount_usd}}</p>
                        <p>{{result.c2visa_amount_uzs}}</p>
                        <p>{{result.c2visa_cnt_usd}}</p>
                        <p>{{result.c2visa_cnt_uzs}}</p>

                    </section>
                    <section class="ifobs-content-child payments">
                        <p>{{result.upbs_amount}}</p>
                        <p>{{result.upbs_cnt}}</p>
                        <p>{{result.upbs_feeamount}}</p>

                    </section>
                    <section class="ifobs-content-child repaymentOfLoans">
                        <p>{{result.visa2c_amount_usd}}</p>
                        <p>{{result.visa2c_amount_uzs}}</p>
                        <p>{{result.visa2c_cnt_usd}}</p>
                        <p>{{result.visa2c_cnt_uzs}}</p>
                    </section>
                    <section class="ifobs-content-child openUsers">
                        <p>{{result.user_front_cnt}}</p>
                        <p>{{result.user_card_amount}}</p>
                    </section>
                    <section class="ifobs-content-child credits">
                        <p>{{result.credit_amount}}</p>
                        <p>{{result.credit_cnt}}</p>
                    </section>
                    <section class="ifobs-content-child incomeDeposits">
                        Поступления депозитов
                        открыто депозитов
                        <p>{{result.opendep_amount_uzs}}</p>
                        <p>{{result.opendep_cnt_uzs}}</p>
                        <p>{{result.opendep_amount_usd}}</p>
                        <p>{{result.opendep_cnt_usd}}</p>

                        пополнение депозитов
                        <p>{{result.debitdep_amount_uzs}}</p>
                        <p>{{result.debitdep_cnt_uzs}}</p>
                        <p>{{result.debitdep_amount_usd}}</p>
                        <p>{{result.debitdep_cnt_usd}}</p>

                        Итого

                        <p>{{result.income_amount_uzs}}</p>
                        <p>{{result.income_amount_usd}}</p>
                    </section>
                    <section class="ifobs-content-child incomeDeposits">
                        Отчисления депозитов
                        списано с депозитов
                        <p>{{result.creditdep_cnt_uzs}}</p>
                        <p>{{result.creditdep_amount_uzs}}</p>
                        <p>{{result.creditdep_amount_usd}}</p>
                        <p>{{result.creditdep_cnt_usd}}</p>
                        Закрыто депозитов
                        <p>{{result.closedep_cnt_uzs}}</p>
                        <p>{{result.closedep_amount_uzs}}</p>
                        <p>{{result.closedep_cnt_usd}}</p>
                        <p>{{result.closedep_amount_usd}}</p>

                        Итого
                        <p>{{result.outcome_amount_uzs}}</p>
                        <p>{{result.outcome_amount_usd}}</p>

                        Разница
                        <p>{{result.full_amount_uzs}}</p>                        
                        <p>{{result.full_amount_uzв}}</p>


                    </section>
                </div>
                <div v-else class="error">
                    <h2>{{result.message}} </h2>
                    <p>код ошибки: {{result.code}}</p>
                </div>
               
                
            </div>
        </div>
      
    </div>

    <script src="js/vue-script.js"></script>
    <script src="js/script.js"></script>
</body>
</html>