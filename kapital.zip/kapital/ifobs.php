<?php  
    session_start();
    if(!isset($_SESSION['user'])){
        header('Location: index.php');
    }
    $data = $_SESSION['data'];
    $sid = $data['result']['sid'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Отчет по iFobs</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Alegreya|IBM+Plex+Serif|Lora|Merriweather|Open+Sans|Philosopher|Play|Roboto+Mono&display=swap" rel="stylesheet">
    <script src="js/vue.js"></script>
</head>
<body>
    <header>
        <img class="logo" src="images/logo.png" alt="logo">
        
        <span class="login" sid="<?php echo($data['result']['sid']);?> "> <?php echo($data['result']['login']); ?></span>
        <a class="nav-link" id="exit" href="core/logout.php">Выйти</a> 
    </header>
    <div class="main">
        <div class="menu">
            <nav class="branch-data">
                <span  class="nav-box">
                    <a class="nav-select" href="data.php">
                        <span>
                            <img class="nav-icons" src="images/icons/home.png" alt="home-icon">
                            <p>Главная</p>
                        </span>
                    </a>
                </span>
                <span class="nav-box">
                    <a class="nav-select" href="branch.php">
                        <span>
                            <img class="nav-icons" src="images/icons/diag.png" alt="home-icon">
                            <p>Отчет по филиалам</p>
                        </span>
                    </a>
                </span>
                <span :class="['nav-box', {active : isActive}]">
                    <a :class="['nav-select', {'nav-select-brd': isActive}]" href="ifobs.php">
                        <span>
                        <img class="nav-icons" src="images/icons/diag2.png" alt="home-icon">
                        <p>Отчет по iFobs</p>
                        </span>
                    </a>
                </span>

            </nav>
        </div>
        <div class="info">
            <?php 
                 $json = array(
                    "sid"=>$sid,
                    "date_begin"=>"19.07.2019",
                    "date_end"=>"19.08.2019"
                );
                $json = json_encode($json);
                $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/GetRep02'); 
                curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
               /*
                set_time_limit(0);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
                curl_setopt($ch, CURLOPT_TIMEOUT, 400); //timeout in seconds
               */ 
                curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
                curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
                $data = curl_exec($ch);
                
                var_dump($data)
            ?>
        </div>
    </div>

    <script src="js/vue-script.js"></script>
</body>
</html>