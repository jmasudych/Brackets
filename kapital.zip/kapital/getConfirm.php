<?php
    session_start();
    $phone = $_SESSION['phone'];
    $code = $_POST['code'];
    $post_data = array(
        'phone'=>$phone,
        'code'=> $code,
    );
    
    $json = json_encode($post_data);    
    $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/ConfirmCode'); 
    curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
    $data = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($data,true);
    $_SESSION['data'] = $json;
    if ($json['error']==NULL){
        echo('yes');
        $_SESSION['authType'] = 1;
        var_dump($data);
        SetCookie("user_phone", $_SESSION['phone']);
        SetCookie("login", $_SESSION['login']);

        header('Location: core/auth.php');
    }
    else{
        $_SESSION['authType'] = 0;
    }
    

?>