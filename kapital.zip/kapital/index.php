<?php     
	session_start();
	//print_r($_COOKIE);
	if(isset($_COOKIE['user_phone'])){
		$title = 'Авторизация';
		$form_action = "core/auth.php";
		$_SESSION['authType'] = 0;

	}
	else{
		$title="Регистрация";
		$form_action = "core/reg.php";

	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo($title); ?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="css/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">

				<div class="wrap-login100">
					<div class="login100-pic js-tilt" data-tilt>
						<img src="images/logo.png" alt="IMG">
					</div>
					<form class="login100-form validate-form" action="<?php echo($form_action); ?>" method='POST'>
						<span class="login100-form-title">
							<?php echo($title); ?>
						</span>
						<?php
							if(isset($_COOKIE['login'])){

								echo('	
									<div class="wrap-input100 validate-input" data-validate = "Valid login is required">
										<input class="input100 readonly" type="text" name="login"  value="'.$_COOKIE['login'].'" placeholder="Login" readonly="readonly">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="fa fa-envelope" aria-hidden="true"></i>
										</span>
									</div>
								');
							}
							else{
								echo('	
									<div class="wrap-input100 validate-input" data-validate = "Valid login is required">
										<input class="input100" type="text" name="login" placeholder="Login">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="fa fa-envelope" aria-hidden="true"></i>
										</span>
									</div>
								');
							}
						?>
						<div class="wrap-input100 validate-input" data-validate = "Password is required">
							<input class="input100" type="password" name="password" placeholder="Password">
							<span class="focus-input100"></span>
							<span class="symbol-input100">
								<i class="fa fa-lock" aria-hidden="true"></i>
							</span>
						</div>
						<?php						
							if(isset($_COOKIE['user_phone'])){

								/*echo('
									<div class="wrap-input100 validate-input" data-validate = "Password is required">
									<input class="input100 readonly" type="text" name="phone" value="'.$_COOKIE['user_phone'].'" placeholder="Phone" readonly="readonly">
									<span class="focus-input100"></span>
									<span class="symbol-input100">
										<i class="fa fa-th" aria-hidden="true"></i>
									</span>
									</div>
								');*/
								echo('
									
									
									<div class="container-login100-form-btn">
										<button class="login100-form-btn">
											Войти
										</button>
									</div>
									<p class="registration"><a class="registration" href="clear-cookie.php">Регистрация<a></p>
								');
							}
							else{
								echo('
									<div class="wrap-input100 validate-input" data-validate = "Password is required">
										<input class="input100" type="text" name="phone" placeholder="Phone">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="fa fa-th" aria-hidden="true"></i>
										</span>
									</div>
									
									<div class="container-login100-form-btn">
										<button class="login100-form-btn">
											Регистрация
										</button>
									</div>
								');
							}
						?>
						
						

					</form>
				</div>
		</div>
	</div>
	<?php
					 if (isset($_GET['error'])) {
						echo('
								
								<div class="alert alert-danger" id="alert" role="alert">
										Ошибка: '.$_GET['msg'].', код ошибки - '.$_GET['code'].'
								</div>
								<div class="bg">
								</div>
							');
					 }
				?>
	

	
<!--===============================================================================================-->	
	<script src="js/jquery.min.js"></script>
<!--===============================================================================================-->
	<script src="js/bootstrap/popper.js"></script>
	<script src="js/bootstrap/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="js/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
    <script src="js/script.js"></script>
</body>
</html>