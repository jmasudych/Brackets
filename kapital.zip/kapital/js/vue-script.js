var app = new Vue({
    el:'.menu',
    data:{
        isActive: true,
        sid:'',
    },

})

var app2 = new Vue({
    el:'.info',
    data() {
        return {
            picked:2,
            date_begin:'',
            date_end: '',
            isShow: false,
            isDateShow: false,
            dateBtn:false,
            tmp: '',
            result:{},
            isContent: false,
        }
    },
    created: function(){
        if(!this.picked){
            this.dateBtn = true;
        }
    },
    watch:{
        picked: function(val){

            if(this.picked){
                this.dateBtn = false;
            }
            if(this.picked==5){
                this.isShow=true;
                this.dateBtn = true

            }
            else{
                this.isShow= false;
                this.isDateShow=false;
                this.isDateShow=false;
                this.date_begin= '';
                this.date_end='';
            }
        
        },
        date_begin:function(val){
            if(this.isShow==true){
                this.isDateShow = true
                this.dateBtn = false
            }
            else{
                this.isDateShow = false
            }
            if(!val&&this.isShow){
                this.dateBtn = true;
            }

        }
    },
    computed:{
    
    },
    methods:{
        click(){
            var self = this;
            self.result = {};
            self.isContent = false;
            if(this.date_end||this.picked!=5){            
                if(this.picked==5){
                    post_data = {
                        picked: this.picked,
                        date_begin: this.date_begin,
                        date_end: this.date_end,
                    }
                   // alert(post_data.date_begin+' - '+post_data.date_end)

                }
                else{
                    if(this.picked==2){
                        function getMonday(d) {
                            d = new Date(d);
                            var day = d.getDay(),
                                diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
                            return new Date(d.setDate(diff));
                        }
                        
                        date = getMonday(new Date()); 
                        if(parseInt(date.getMonth())<10&&parseInt(date.getMonth())>0){
                            dateMonth = '0'+(parseInt(date.getMonth())+1);
                        }
                        else{
                            dateMonth = date.getMonth();
                        }
                        if(parseInt(date.getDate())<10&&parseInt(date.getDate())>0){
                            dateDay = '0'+date.getDate();
                        }
                        else{
                            dateDay = date.getDate();
                        }
                        resDate1 = dateDay+'.'+dateMonth+'.'+date.getFullYear();
                        date = new Date();
                        
                        if(parseInt(date.getDate())<10&&parseInt(date.getDate())>0){
                            dateDay = '0'+date.getDate();
                        }
                        else{
                            dateDay = date.getDate();
                        }

                        resDate2 = dateDay+'.'+dateMonth+'.'+date.getFullYear();
                    }
                    else if(this.picked==1){
                        date = new Date();
                        if(parseInt(date.getMonth())<10&&parseInt(date.getMonth())>0){
                            dateMonth = '0'+(parseInt(date.getMonth())+1);
                        }
                        else{
                            dateMonth = date.getMonth();
                        }
                        if(parseInt(date.getDate())<10&&parseInt(date.getDate())>0){
                            dateDay = '0'+date.getDate();
                        }
                        else{
                            dateDay = date.getDate();
                        }
                        resDate1 = dateDay+'.'+dateMonth+'.'+date.getFullYear();
                        resDate2 = resDate1;
                    }
                    else if(this.picked==3){
                        var date = new Date();
                        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
                        if(parseInt(firstDay.getMonth())<10&&parseInt(firstDay.getMonth())>0){
                            dateMonth = '0'+(parseInt(date.getMonth())+1);
                        }
                        else{
                            dateMonth = date.getMonth();
                        }
                        if(parseInt(firstDay.getDate())<10&&parseInt(firstDay.getDate())>0){
                            dateDay1 = '0'+firstDay.getDate();
                        }
                        else{
                            dateDay1 = firstDay.getDate();
                        }
                        if(parseInt(date.getDate())<10&&parseInt(date.getDate())>0){
                            dateDay2 = '0'+date.getDate();
                        }
                        else{
                            dateDay2 = date.getDate();
                        }
                        resDate1 = dateDay1+'.'+dateMonth+'.'+firstDay.getFullYear();
                        resDate2 = dateDay2+'.'+dateMonth+'.'+date.getFullYear();
                    }
                    else if(this.picked==4){
                        resDate1 = '';
                        resDate2 = '';
                    }


                    post_data = {
                        picked: this.picked,
                        date_begin: resDate1,
                        date_end: resDate2
                    }
                    //alert(post_data.date_begin+' - '+post_data.date_end)
                }
                $.ajax({
                    type: "POST",
                    url: "core/get_ifobs.php",
                    data: post_data,
                    success: function (response) {
                        var json = jQuery.parseJSON(response);
                        console.log(json.result);
                        self.result = json.result;
                        self.isContent = true;
                    },
                    error: function(){
                        alert('error')
                    }
                });
            }
            else{
                alert('Выберите конец периода')
            }
        }
    }

})