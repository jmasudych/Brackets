<?php
        session_start();
        $data =  $_SESSION['data'];
        $sid = $data['result']['sid'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Отчет по филиалам</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Alegreya|IBM+Plex+Serif|Lora|Merriweather|Open+Sans|Philosopher|Play|Roboto+Mono&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
    <script src="js/vue.js"></script>
    <script src="js/vue-chartjs.min.js"></script>

</head>
<body>
    <header>
        <img class="logo" src="images/logo.png" alt="logo">
        <span class="login" sid="<?php echo($data['result']['sid']);?> "> <?php echo($data['result']['login']); ?></span>
        <a class="nav-link" id="exit" href="core/logout.php">Выйти</a> 
    </header>
    <div class="main">
        <div class="menu">
            <nav class="branch-data">
                <span  class="nav-box">
                    <a class="nav-select" href="data.php">
                        <span>
                            <img class="nav-icons" src="images/icons/home.png" alt="home-icon">
                            <p>Главная</p>
                        </span>
                    </a>
                </span>
                <span :class="['nav-box', {active : isActive}]">
                    <a :class="['nav-select', {'nav-select-brd': isActive}]" href="branch.php">
                        <span>
                            <img class="nav-icons" src="images/icons/diag.png" alt="home-icon">
                            <p>Отчет по филиалам</p>
                        </span>
                    </a>
                </span>
                <span class="nav-box">
                    <a class="nav-select" href="ifobs.php">
                        <span>
                        <img class="nav-icons" src="images/icons/diag2.png" alt="home-icon">
                        <p>Отчет по iFobs</p>
                        </span>
                    </a>
                </span>

            </nav>
        </div>
        <div class="info">
            <div class="container main-cont">
                <div class="branch-container">
                    <h2 class="branch-headline">Отчет по филиалам</h2>
                    <span class="date-box">
                        <label class="date-branch-control" title="Дата отчета" for="branch-date">Дата:</label>
                        <input class="form-control" title="Дата отчета" id="branch-date" type="date" name="date">
                    </span>
                    <input class="btn" id="branch-btn"  type="button" value="Получить">
                </div>
                <div class="error-branch"></div>
                <div style="width:100%;height:570px">
                    <canvas id="myChart" ></canvas>

                </div>
            </div>
        </div>
    </div>
   
    
    <script src="js/jquery.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/vue-script.js"></script>
</body>
</html>