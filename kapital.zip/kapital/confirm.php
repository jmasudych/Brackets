<?php
	session_start();
	$data =   $_SESSION['data'];
	

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Подтверждение номера</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="css/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">

				<div class="wrap-login100">
					<div class="login100-pic js-tilt" data-tilt>
						<img src="images/logo.png" alt="IMG">
					</div>
					<form class="login100-form validate-form" action="./getConfirm.php" method='POST'>
						<span class="login100-form-title">
							Подтверждение номера
						</span>

						<div class="wrap-input100 validate-input" data-validate = "Valid code is required">
							<input class="input100" type="text" name="code"  autocomplete="off" placeholder="Введите код подтверждения">
							<span class="focus-input100"></span>
							<span class="symbol-input100">
								<i class="fa fa-th" aria-hidden="true"></i>
							</span>
						</div>

						
						<div class="container-login100-form-btn">
							<button class="login100-form-btn">
								OK
							</button>
							<span id="timer" time="<?php echo($data['waiting_sec']); ?>"></span>

						</div>
						<script>
							elem = document.getElementById("timer");

							var upgradeTime = elem.getAttribute("time");
							var seconds = upgradeTime;
							function timer() {
								var days        = Math.floor(seconds/24/60/60);
								var hoursLeft   = Math.floor((seconds) - (days*86400));
								var hours       = Math.floor(hoursLeft/3600);
								var minutesLeft = Math.floor((hoursLeft) - (hours*3600));
								var minutes     = Math.floor(minutesLeft/60);
								var remainingSeconds = seconds % 60;
								if (remainingSeconds < 10) {
									remainingSeconds = "0" + remainingSeconds; 
								}
								document.getElementById('timer').innerHTML =  minutes + ":" + remainingSeconds;
								if (seconds == 0) {
									clearInterval(countdownTimer);
									document.getElementById('timer').innerHTML = "Completed";
									window.location.href='index.php'
								} else {
									seconds--;
								}
							}
							var countdownTimer = setInterval('timer()', 1000);
						</script>
					</form>
				</div>
		</div>
	</div>

	
<!--===============================================================================================-->	
	<script src="js/jquery.min.js"></script>
<!--===============================================================================================-->
	<script src="js/bootstrap/popper.js"></script>
	<script src="js/bootstrap/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="js/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
    <script src="js/script.js"></script>
</body>
</html>