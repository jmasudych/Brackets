<?php
	SetCookie("login", null);
	SetCookie("user_phone", null);
    header('Location: index.php');

?>