<?php
    session_start();
    if(!isset($_SESSION['user'])){
        header('Location: index.php');

    }
    $data = $_SESSION['data'];
   //var_dump($data);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Alegreya|IBM+Plex+Serif|Lora|Merriweather|Open+Sans|Philosopher|Play|Roboto+Mono&display=swap" rel="stylesheet">
    <script src="js/vue.js"></script>
    <script src="js/vue-chartjs.min.js"></script>

    <title>Главная страница</title>
</head>
<body>
    <header>
        <img class="logo" src="images/logo.png" alt="logo">
        
        <span class="login" sid="<?php echo($data['result']['sid']);?> "> <?php echo($data['result']['login']); ?></span>
        <a class="nav-link" id="exit" href="core/logout.php">Выйти</a> 
    </header>
    <!--
    <main>
        <div class="menu">
            <div class="branch-data">
                <button type="button" class="btn btn-outline-secondary pb-80" id="get-branch"><a href="branch.php">Отчет по филиалам</a></button>
            </div>
        </div>
        <div class="main-info">
            <h1>Информация о клиентах</h1>
            <div class="container">
            <?php
                    for($i=0;$i<count($data['result']['clients']);$i++){
                    
                    echo('
                    <div class="box" clients_id="'.$data['result']['clients'][$i]['id'].'">
                        <div class="date">'.$data['result']['clients'][$i]['oper_day'].'</div>
                        <div class="content">
                            <div class="first-child">
                                <p>Название организации:</p>
                                <p>Код филиала:</p>
                                <p>Код клиента:</p>
                            </div>
                            <div class="second-child">
                                <p>'.$data['result']['clients'][$i]['name'].'</p>
                                <p>'.$data['result']['clients'][$i]['branch'].'</p>
                                <p>'.$data['result']['clients'][$i]['code'].'</p>
                            </div>
                        </div>
                        <div class="more">
                
                                <form id="more" action="info.php" method="POST">
                                    <input class="hdn" type="text" name="i" value="'.$i.'">    
                                    <input class="more-child" type="submit" value="Подробнее">    
                                </form>
                
                        </div>
                        
                    </div>
                    ');
                }  
            ?>  
        </div>
    </main>
            -->
    <div class="main">
        <div class="menu">
            <nav class="branch-data">
                <span :class="['nav-box', {active : isActive}]">
                    <a :class="['nav-select', {'nav-select-brd': isActive}]" href="data.php">
                        <span>
                            <img class="nav-icons" src="images/icons/home.png" alt="home-icon">
                            <p>Главная</p>
                        </span>
                    </a>
                </span>
                <span class="nav-box">
                    <a class="nav-select" href="branch.php">
                        <span>
                            <img class="nav-icons" src="images/icons/diag.png" alt="home-icon">
                            <p>Отчет по филиалам</p>
                        </span>
                    </a>
                </span>
                <span class="nav-box">
                    <a class="nav-select" href="ifobs.php">
                        <span>
                        <img class="nav-icons" src="images/icons/diag2.png" alt="home-icon">
                        <p>Отчет по iFobs</p>
                        </span>
                    </a>
                </span>

            </nav>
        </div>
        <div class="info">
        <h1>Информация о клиентах</h1>
            <div class="container">
            <?php
                    if(count((array)$data['result']['clients'])!=0){
                        for($i=0;$i<count($data['result']['clients']);$i++){      
                            echo('
                                <div class="box" clients_id="'.$data['result']['clients'][$i]['id'].'">
                                    <div class="date">'.$data['result']['clients'][$i]['oper_day'].'</div>
                                    <div class="content">
                                        <div class="first-child">
                                            <p>Название организации:</p>
                                            <p>Код филиала:</p>
                                            <p>Код клиента:</p>
                                        </div>
                                        <div class="second-child">
                                            <p>'.$data['result']['clients'][$i]['name'].'</p>
                                            <p>'.$data['result']['clients'][$i]['branch'].'</p>
                                            <p>'.$data['result']['clients'][$i]['code'].'</p>
                                        </div>
                                    </div>
                                    <div class="more">
                            
                                            <form id="more" action="info.php" method="POST">
                                                <input class="hdn" type="text" name="i" value="'.$i.'">    
                                                <input class="more-child" type="submit" value="Подробнее">    
                                            </form>
                            
                                    </div>
                                    
                                </div>
                            ');
                        }  
                    }
                    else{
                        echo('Нет клиентов');
                    }
            ?>  

        </div>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/vue-script.js"></script>
</body>
</html>

