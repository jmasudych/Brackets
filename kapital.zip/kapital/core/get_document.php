<?php
require('fpdf.php');

   class myPDF extends FPDF{
        function header(){
            $this -> SetFront('Arial','B',14);
            $this-> Cell(276,5,'EMPLOYEE DOCUMENTS', 0,0,'C');
            $this->Ln();
            $this->Cell(276,10,'Street Address of employye office',0,0,'C');
        }
        function footer(){
            $this->SetY(-15);
            $this-> SetFront('Arial','',8);
            $this->Cell(0,10,'Page '.$this->PageNo().'\{nb}',0,0,'C');
        }
   }

   $pdf = new myPDF();
   $pdf ->AliasNbPages();
   $pdf ->AddPage('L', 'A4', 0);
   $pdf -> Output();
?>