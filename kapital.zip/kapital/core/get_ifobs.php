<?php   
    session_start();
    $postType = $_POST['picked'];
    $sid = $_SESSION['data']['result']['sid'];
    $date_begin = $_POST['date_begin'];
    $date_end = $_POST['date_end'];

    if($postType==5){
        
        list($year, $month, $day) = explode('-', $date_begin,3 );
        $date_begin= $day.'.'.$month.'.'.$year;

        list($year, $month, $day) = explode('-', $date_end,3 );
        $date_end= $day.'.'.$month.'.'.$year;
    }

    $json = array(
    "sid"=>$sid,
    "date_begin"=>$date_begin,
    "date_end"=>$date_end
    );
    $json = json_encode($json);
    $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/GetRep02'); 
    curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
    /*
    set_time_limit(0);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 400); //timeout in seconds
    */ 
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
    $data = curl_exec($ch);
    
    echo $data;

?>