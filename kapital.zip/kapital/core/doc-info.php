<?php
    session_start();

    function toSum($value){
        $value = $value / 100; 
        $res = number_format($value, 2, '.', ' ');
        return $res;
    }
    function toSumforPDF($value){
        $value = $value / 100; 
        $res = number_format($value, 2, '.', '');
        return $res;
    }

    $res = $_SESSION['documents'];
    $i = $_POST['i'];
    $date = $_POST['date'];
    $num = $res['result'][$i]['num'];
    $dtype = $res['result'][$i]['dtype'];

    $name_dt = $res['result'][$i]['name_dt'];
    $mfo_dt = $res['result'][$i]['mfo_dt'];
    $acc_dt = $res['result'][$i]['acc_dt'];
    $inn_dt = $res['result'][$i]['inn_dt'];

    $name_ct = $res['result'][$i]['name_ct'];
    $mfo_ct = $res['result'][$i]['mfo_ct'];
    $acc_ct = $res['result'][$i]['acc_ct'];
    $inn_ct = $res['result'][$i]['inn_ct'];
    
    $purp_code = $res['result'][$i]['purp_code'];
    $purpose = $res['result'][$i]['purpose'];
    $amount = toSum($res['result'][$i]['amount']);
    $amount_for_pdf = toSumforPDF($res['result'][$i]['amount']);
    $state = $res['result'][$i]['state'];
    $err_msg = $res['result'][$i]['err_msg'];
    $arr = array('date' => $date, 'num'=>$num, 'err_msg'=>$err_msg, 'amountPDF'=> $amount_for_pdf, 'dtype' =>$dtype, 'name_dt'=>$name_dt, 'mfo_dt'=>$mfo_dt,'acc_dt' => $acc_dt, 'inn_dt'=>$inn_dt, 'name_ct' =>$name_ct, 'mfo_ct'=>$mfo_ct, 'acc_ct'=>$acc_ct, 'inn_ct'=> $inn_ct, 'purp_code' => $purp_code, 'purpose' => $purpose, 'amount' => $amount, 'state'=> $state);  
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
?>