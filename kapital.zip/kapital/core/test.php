<?php
    print_r($_COOKIE);
    echo($_COOKIE['Test']);
    echo($_COOKIE['user_phone']);

?>