<?php
    session_start();
    $login = $_POST['login'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $_SESSION['login'] = $login;
    $_SESSION['password'] = $password;
    $_SESSION['phone'] = $phone;


    $post_data = array(
        'login'=> $login,
        'password'=> $password,
        'phone'=>$phone,
    );
    
    $json = json_encode($post_data);    
    $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/RegisterPhoneV2'); 
    curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
    $data = curl_exec($ch);
    curl_close($ch);
    $json = json_decode($data,true);
    $_SESSION['data'] = $json;
    if ($json['error']==NULL){
        echo('yes');
        header('Location: ../confirm.php');
    }
    else{
        echo '<script type="text/javascript">

        document.location.href="../index.php?error&code='.$json['error']['code'].'&msg='.$json['error']['message'].'";</script>';
    } 

?>