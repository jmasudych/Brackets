<?php
    session_start();

    $date = $_POST['date'];
    list($year, $month, $day) = explode('-', $date,3 );
    $date= $day.'.'.$month.'.'.$year;

    $sid = $_SESSION['data']['result']['sid'];

    $post_data = array(
        'sid'=> $sid,
        'date'=>$date
    );
    $json = json_encode($post_data);    
    $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/GetRep01'); 
    curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
    $res = curl_exec($ch);
    curl_close($ch);
    //$result = json_decode($res,true);
    echo($res);
?>