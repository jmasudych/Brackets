<?php

    $json = array(
        "sid"=>"1mhKXAWTem8F",
        "date_begin"=>"19.07.2019",
        "date_end"=>"19.08.2019"
    );
    $json = json_encode($json);
    $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/GetRep02'); 
    curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
   /*
    set_time_limit(0);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 400); //timeout in seconds
   */ 
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
    $data = curl_exec($ch);
    
    var_dump($data)
    /*
    "phone"=>"+998911320434", 
    "code"=>"3671"*/
    
?>
