<?php
    session_start();
    if(!isset($_SESSION['user'])){
        header('Location: index.php');
    }
    $i = $_POST['i'];
    $data = $_SESSION['data'];
    $date = $data['result']['clients'][$i]['oper_day'];
    $clients_id = $data['result']['clients'][$i]['id'];
    $data       = $_SESSION['data'];
    $login      = $data['result']['login'];
    $sid        = $data['result']['sid'];

    function toSum($value){
        $value = $value / 100; 
        $res = number_format($value, 2, '.', ' ');
        return $res;
    }

    $post_data = array(
        'client_id'=> $clients_id,
        'sid'=> $sid
    );
    $json = json_encode($post_data);    
    $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/GetAccounts'); 
    curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
    $res = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($res,true);

   //var_dump($result);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Список счетов клиента</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" href="css/info.css">
    <link href="https://fonts.googleapis.com/css?family=Alegreya|IBM+Plex+Serif|Lora|Merriweather|Open+Sans|Philosopher|Play|Roboto+Mono&display=swap" rel="stylesheet">

</head>
<body>
    <header>
        <div class="header-left-child">
            <img class="logo" src="images/logo.png" alt="logo">
        </div>
        <div class="branch">
            <button type="button" class="btn btn-outline-secondary pb-80" id="back-btn">Назад</button>
        </div>
        <div class="header-right-child">
            <span class="login"> <?php echo($data['result']['login']); ?></span>
            <a class="nav-link" id="exit" href="core/logout.php">Выйти</a> 
        </div>

    </header>
    <main>
        <div class="container context">
            <div class="head">
                <div class="left-child">
                    <div class="date-info"><?php echo($date); ?></div>
                        <div class="content">
                            <div class="first-child">
                                <p>Название организации:</p>
                                <p>Код филиала:</p>
                                <p>Код клиента:</p>
                            </div>
                            <div class="second-child">
                                <p><?php echo($data['result']['clients'][$i]['name']); ?></p>
                                <p><?php echo($data['result']['clients'][$i]['branch']);?></p>
                                <p><?php echo($data['result']['clients'][$i]['code']); ?></p>
                            </div>
                    </div>
                </div>
                <form action="documents.php" method="POST">
                    <div class="right-child">
                        <h4>Список документов</h4>
                        <span class="date-control">
                            <label class="date-label" title="Дата, за которую запрашиваем список документов" for="doc">Дата:</label>
                            <input class="form-control" title="Дата, за которую запрашиваем список документов" id="doc" type="date" name="date">
                            <input class="hdn" type="text" name="i" value="<?php echo($i) ?>">
                        </span>
                        <button type="submit" class="btn doc-btn">Получить</button>
                    </div>
                </form>
            </div>
            <div class="accounts">
                <div class="headline">
                    <h5 class="headline-text">Список счетов клиента</h5>
                </div>
                <div class="accounts-content">
                    <?php
                        for($j = 0; $j<count($result['result']); $j++){
                            echo('
                            <div class="accounts-box">
                                <div class="accounts-box-child-1">
                                        <p>Название счета:</p>
                                        <p>Счет:</p>
                                        <p>Дата проводки:</p>
                                        <p>Сальдо на начало дня:</p>
                                        <p>Сальдо на конец дня:</p>
                                        <p>Обороты по кредиту:</p>
                                        <p>Обороты по дебету:</p>
                                </div>
                                <div class="accounts-box-child-2">
                                    <p>'.$result['result'][$j]['name'].'</p>
                                    <p>'.$result['result'][$j]['account'].'</p>
                                    <p>'.$result['result'][$j]['l_date'].'</p>
                                    <p>'.toSum($result['result'][$j]['s_in']).' сум</p>
                                    <p>'.toSum($result['result'][$j]['s_out']).' сум</p>
                                    <p>'.toSum($result['result'][$j]['ct']).' сум</p>
                                    <p>'.toSum($result['result'][$j]['dt']).' сум</p>
                                </div>
                            </div>
                            ');
                        }
                   ?>
                </div>
            </div>

              
           
        </div>
        <br><br>
    </main>

    <script src="js/jquery.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>