<?php
    session_start();
    $date = $_POST['date'];
    list($year, $month, $day) = explode('-', $date,3 );
    $date= $day.'.'.$month.'.'.$year;
    $data = $_SESSION['data'];
    $i = $_POST['i'];
    $sid = $_SESSION['data']['result']['sid'];
    $clients_id = $data['result']['clients'][$i]['id'];
    function toSum($value){
        $value = $value / 100; 
        $res = number_format($value, 2, '.', ' ');
        return $res;
    }
    

    $post_data = array(
        'client_id'=> $clients_id,
        'sid'=> $sid,
        "date"=> $date
    );
    $json = json_encode($post_data);    
    $ch = curl_init('https://m.bank24.uz:2713/Mobile.svc/GetDocuments'); 
    curl_setopt($ch, CURLOPT_POST, 1); //переключаем запрос в POST
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json); //Это POST данные
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER ,1); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Отключим проверку сертификата https
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //из той же оперы
    $res = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($res,true);
    $_SESSION['documents'] = $result;
    //var_dump($res);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Список документов</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" href="css/info.css">
    <link href="https://fonts.googleapis.com/css?family=Alegreya|IBM+Plex+Serif|Lora|Merriweather|Open+Sans|Philosopher|Play|Roboto+Mono&display=swap" rel="stylesheet">
    <script src="js/jsPDF/jspdf.js"></script>
    <script src="js/jsPDF/FileSaver.js"></script>
    <script src="js/jsPDF/ttffont.js"></script>
    <script src="js/jsPDF/ttfsupport.js"></script>
    <script src="js/jsPDF/utf8.js"></script>
    <script src="js/jsPDF/vfs.js"></script>
    <script src="js/summapropi.js"></script>
</head>
<body>
    <header>
        <div class="header-left-child">
            <img class="logo" src="images/logo.png" alt="logo">
            
        </div>
        <div class="branch">
            <form class="back-doc-form" action="info.php" method="POST">
                <input class="hdn" type="text" name="i" value="<?php echo($i); ?>">
                <button type="submit" class="btn btn-outline-secondary" id="back-btn-doc">Назад</button>
            </form>


        </div>
        <div class="header-right-child">
            <span class="login"> <?php echo($data['result']['login']); ?></span>
            <a class="nav-link" id="exit" href="core/logout.php">Выйти</a> 
        </div>
    </header>
    <?php 

    if(!$result['result']) echo('<h1 class="doc-headline">Нет документов</h1>');
    else {

    ?>
    <h1 class="doc-headline">Документы</h1>
    <main class="container main-doc">
        
        <?php
            for($j = 0;$j<count($result['result']);$j++){
                $state = '';
                $color = '';
                $dir = $result['result'][$j]['dir'];
                $first_name = 'name_ct or name_dt';
                if($dir == 1){
                    $first_name = $result['result'][$j]['name_ct'];
                    $clr = '#bd3333';
                    $sign = '-';
                }
                else if($dir == 2){
                    $first_name = $result['result'][$j]['name_dt'];
                    $clr = 'green';
                    $sign = '+';
                }
                if($result['result'][$j]['state']==3){
                    $state = 'Проведен';

                }
                else if($result['result'][$j]['state']){
                    $state = 'Удален';
                    $color = '#bd3333';
                }
                echo('
                        <div class="documents-box">
                            <div class="document-box-header">
                                <div class="date">'.$date.'</div>
                                <div class="doc-number">Номер документа: '.$result['result'][$j]['num'].'</div>
                            </div>
                            
                            <span class="document-box-content-top">
                                <h4>'.$first_name.'</h4>
                            </span>
                            <span class="document-box-content-bottom">
                                <span class="document-box-content-bottom-left" style="color: '.$color.' ">'.$state.'</span>
                                <span class="document-box-content-bottom-right" style="color: '.$clr.'">'.$sign.toSum($result['result'][$j]['amount']).' сум</span>
                            </span>
                            <span class="document-box-content-footer" title="'.$result['result'][$j]['purpose'].'">
                                '.$result['result'][$j]['purpose'].'
                            </span>   
                            <div class="blocText" ii="'.$j.'" date="'.$date.'">
                                <div class="text" >
                                    <h2>Подробнее</h2>
                                </div>
                            </div>
                        </div>

                ');
            }
        ?>
    </main>
        <?php } ?>
    <script src="js/jquery.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>